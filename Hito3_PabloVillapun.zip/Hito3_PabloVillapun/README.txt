Pablo Villapun Martin

Implementado:
-Menu principal, contiene sliders laterales para los apartados de amigos y noticias del juego. En la parte
central se encuentra el logo, un coche que lleva al menu garaje y cuatro indicadores que muestran si hay
amigos en tu sala.

-Menu Ajustes: Consistente en seleccionar tanto el ajuste de sonido de salida como de entrada. Dos sliders
que regulan el volumen de salida y de entrada.